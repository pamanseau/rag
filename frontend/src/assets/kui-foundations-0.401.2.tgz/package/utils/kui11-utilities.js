// @ts-check
import {
	DarkTheme as darkThemeOverride,
	theme as kui11Theme,
} from "@kui-shared/all";

/**
 * @typedef {{ value: string, variable: string }} Token
 */

/**
 * @param {Token | string} token
 */
function getFallbackValue(token) {
	if (typeof token === "string") {
		return token;
	}
	return `var(${token.variable},${token.value})`;
}

/**
 * @param {Record<string, string | Token>} obj
 * @param {string} twProperty
 * @param {{prefix?: string, suffix?: string}} options
 */
function mapToUtilities(obj, twProperty, { prefix = "", suffix = "" } = {}) {
	/**
	 * @param {Token | string} tokenOrValue
	 */
	const toTwArbitraryValue = (tokenOrValue) => {
		/**
		 * Tailwind cannot infer the type from a CSS variable, so in those cases we need to provide a hint
		 * to let it know what property to generate.
		 * https://v3.tailwindcss.com/docs/adding-custom-styles#resolving-ambiguities
		 */
		const HINTS = {
			borderWidths: "length",
			colors: "color",
			fontSizes: "length",
			shadows: "shadow",
		};
		let value = "";
		if (typeof tokenOrValue === "string") {
			value = tokenOrValue.replace(/ /g, "_");
		} else {
			const hint = Object.entries(HINTS).find(([key]) =>
				tokenOrValue.variable.includes(key),
			)?.[1];
			value = `${hint ? `${hint}:` : ""}var(${tokenOrValue.variable},${tokenOrValue.value})`;
		}
		return value.replace(/ /g, "_");
	};

	/**
	 * @param {string} name
	 * @param {Token | string} tokenOrValue
	 */
	const getUtilityCss = (name, tokenOrValue) => {
		const darkThemeValue =
			darkThemeOverride.colors[
				/** @type {keyof typeof darkThemeOverride.colors} */ (name)
			] ||
			darkThemeOverride.shadows[
				/** @type {keyof typeof darkThemeOverride.shadows} */ (name)
			];
		const baseCss = `@apply ${twProperty}-[${toTwArbitraryValue(tokenOrValue)}]`;
		return darkThemeValue?.value &&
			darkThemeValue.value !==
				(typeof tokenOrValue === "string" ? tokenOrValue : tokenOrValue.value)
			? baseCss + ` dark:${twProperty}-[${toTwArbitraryValue(darkThemeValue)}]`
			: baseCss;
	};

	return Object.entries(obj).reduce(
		(acc, [name, tokenOrValue]) => ({
			...acc,
			[`.${prefix}${twProperty}-deprecated-kui11-${name}${suffix}`]:
				getUtilityCss(name, tokenOrValue),
		}),
		{},
	);
}

const PLUGIN_UTILITIES = {
	// Color utilities
	bg: kui11Theme.colors,
	text: {
		...kui11Theme.colors,
		...kui11Theme.fontSizes,
		mm: "18px",
	},
	border: {
		...kui11Theme.borderWidths,
		...kui11Theme.colors,
	},
	divide: kui11Theme.colors,
	ring: kui11Theme.colors,
	placeholder: kui11Theme.colors,
	accent: kui11Theme.colors,
	outline: kui11Theme.colors,
	caret: kui11Theme.colors,
	fill: kui11Theme.colors,
	to: kui11Theme.colors,
	from: kui11Theme.colors,

	// Space utilities
	p: kui11Theme.space,
	pt: kui11Theme.space,
	pb: kui11Theme.space,
	pl: kui11Theme.space,
	pr: kui11Theme.space,
	px: kui11Theme.space,
	py: kui11Theme.space,
	m: kui11Theme.space,
	mt: kui11Theme.space,
	mb: kui11Theme.space,
	ml: kui11Theme.space,
	mr: kui11Theme.space,
	mx: kui11Theme.space,
	my: kui11Theme.space,
	gap: kui11Theme.space,
	inset: kui11Theme.space,

	// Other utilities
	leading: kui11Theme.lineHeights,
	rounded: kui11Theme.borderRadius,
	font: kui11Theme.fontWeights,
	tracking: {
		...kui11Theme.letterSpacings,
		wide: "0.1rem",
	},
	opacity: { 8: "8%" },
	shadow: {
		...kui11Theme.shadows,
		insetShadowLightLow: "1px 1px 2px 0 #00000066",
		insetShadowLightLower: "2px 2px 3px 0 #00000033",
		insetShadowLightLowest: "0px 1px 5px 0 #0000004d",
		insetShadowDarkLow: "1px 1px 2px 0 #00000099",
		insetShadowDarkLower: "2px 2px 3px 0 #00000066",
		insetShadowDarkLowest: "0px 1px 5px 0 #00000099",
	},
};

/**
 * @type {{ [key in keyof Partial<typeof PLUGIN_UTILITIES>]: {prefix?: string, suffix?: string} }}
 */
const PLUGIN_UTILITIES_OPTIONS = {
	placeholder: { suffix: "::placeholder" },
};

export function getKui11Utilities() {
	return Object.entries(PLUGIN_UTILITIES)
		.map(([key, value]) =>
			mapToUtilities(
				value,
				key,
				PLUGIN_UTILITIES_OPTIONS[
					/** @type {keyof typeof PLUGIN_UTILITIES_OPTIONS} */ (key)
				],
			),
		)
		.reduce((acc, curr) => ({ ...acc, ...curr }), {});
}

/**
 * Generates a Tailwind 4 KUI11 theme.
 */
export function getTailwind4Kui11Theme() {
	const colorVariables = Object.entries(kui11Theme.colors)
		.map(
			([key, value]) =>
				`--color-deprecated-kui11-${key}: ${getFallbackValue(value)};`,
		)
		.join("\n  ");
	const spaceVariables = Object.entries(kui11Theme.space)
		.map(
			([key, value]) =>
				`--spacing-deprecated-kui11-${key}: ${getFallbackValue(value)};`,
		)
		.join("\n  ");
	const fontSizeVariables = Object.entries(kui11Theme.fontSizes)
		.map(
			([key, value]) =>
				`--text-deprecated-kui11-${key}: ${getFallbackValue(value)};`,
		)
		.join("\n  ");
	const fontWeightVariables = Object.entries(kui11Theme.fontWeights)
		.map(
			([key, value]) =>
				`--font-weight-deprecated-kui11-${key}: ${getFallbackValue(value)};`,
		)
		.join("\n  ");
	const lineHeightVariables = Object.entries(kui11Theme.lineHeights)
		.map(
			([key, value]) =>
				`--leading-deprecated-kui11-${key}: ${getFallbackValue(value)};`,
		)
		.join("\n  ");
	const letterSpacingVariables = Object.entries({
		...kui11Theme.letterSpacings,
		wide: "0.1rem",
	})
		.map(
			([key, value]) =>
				`--tracking-deprecated-kui11-${key}: ${getFallbackValue(value)};`,
		)
		.join("\n  ");
	const radiusVariables = Object.entries(kui11Theme.borderRadius)
		.map(
			([key, value]) =>
				`--radius-deprecated-kui11-${key}: ${getFallbackValue(value)};`,
		)
		.join("\n  ");
	const shadowVariables = Object.entries({
		...kui11Theme.shadows,
		insetShadowLightLow: "1px 1px 2px 0 #00000066",
		insetShadowLightLower: "2px 2px 3px 0 #00000033",
		insetShadowLightLowest: "0px 1px 5px 0 #0000004d",
		insetShadowDarkLow: "1px 1px 2px 0 #00000099",
		insetShadowDarkLower: "2px 2px 3px 0 #00000066",
		insetShadowDarkLowest: "0px 1px 5px 0 #00000099",
	})
		.map(
			([key, value]) =>
				`--shadow-deprecated-kui11-${key}: ${getFallbackValue(value)};`,
		)
		.join("\n  ");

	return `@theme inline {
  ${colorVariables}
  ${spaceVariables}
  ${fontSizeVariables}
  ${fontWeightVariables}
  ${lineHeightVariables}
  ${letterSpacingVariables}
  ${radiusVariables}
  ${shadowVariables}
}`;
}
