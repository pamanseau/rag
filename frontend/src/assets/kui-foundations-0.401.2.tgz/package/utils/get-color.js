import designTokens from "../theme/design-tokens.js";

const COLORS = designTokens["primitives-color"];

/**
 * @remarks
 * A utility function to get the color from the primitive colors object.
 * @param {keyof typeof COLORS} color - The color to get.
 * @returns {string} The color.
 */
export function getColor(color) {
	// remove the comment from the color
	return (COLORS[color] || color).replace(/\/\*.*?\*\//g, "").trim();
}
