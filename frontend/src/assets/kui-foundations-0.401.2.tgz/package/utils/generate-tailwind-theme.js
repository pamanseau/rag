/**
 * @typedef {typeof kuiDesignTokens} KuiDesignTokens
 */
import kuiDesignTokens from "../theme/design-tokens.js";
import {
	getAllValues,
	getCssVariable,
	getFromTheme,
} from "./design-token-utils.js";

export const tailwindFormattedTheme = {
	// typography
	fontFamily: Object.entries({
		"--font-sans":
			kuiDesignTokens["primitives-typography"]["--font-family-nvidia-sans"],
		"--font-mono":
			kuiDesignTokens["primitives-typography"]["--font-family-jetbrains-mono"],
	}),
	fontSize: getFromTheme("primitives-typography", "font-size-"),
	fontWeight: getFromTheme("primitives-typography", "font-weight-").filter(
		([key]) => !key.includes("mono-regular"),
	),
	lineHeight: getFromTheme("primitives-typography", "line-height-"),
	letterSpacing: Object.entries(kuiDesignTokens["effects"]["text-styles"])
		.map(([type, value]) => [type, value.letterSpacing])
		.filter(([_, letterSpacing]) => letterSpacing !== undefined)
		.map(([type, letterSpacing]) => [
			`--tracking-${type.replaceAll("/", "-")}`,
			letterSpacing,
		]),
	// colors
	primitiveColors: getFromTheme("primitives-color"),
	lightThemeColors: getFromTheme("theme-light"),
	backgroundColors: getFromTheme("theme-light", "-background"),
	foregroundIconColors: getFromTheme("theme-light", ["-foreground", "-icon"]),
	borderColors: getFromTheme("theme-light", "-border"),
	// sizes
	breakpoints: getFromTheme("primitives-size", "breakpoint-"),
	borderRadius: getFromTheme("primitives-size", "radius-"),
	borderWidth: getFromTheme("primitives-size", "border-"),
	semanticSizes: getFromTheme("density-standard", "spacing-"),
	// effects
	shadows: getFromTheme("effects", "--shadows"),
	backdropFilters: getFromTheme(
		"effects",
		"backdrop-filters-surface-glass-blur",
	),
	animation: {
		pulse: "pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite",
	},
	transitionDuration: {
		150: "150ms",
		200: "200ms",
		250: "250ms",
		300: "300ms",
	},
	transitionTimingFunction: {
		out: "cubic-bezier(0.4, 0, 0.2, 1)",
	},
};

function getThemedValue(variable) {
	const variableName = getCssVariable(variable).declaration;
	const { "theme-light": lightToken, "theme-dark": darkToken } =
		getAllValues(variable);
	const lightValue = kuiDesignTokens["primitives-color"][lightToken];
	const darkValue = kuiDesignTokens["primitives-color"][darkToken];
	const formatToken = (token) => token.replace("--", "--color-");
	const comment =
		lightValue === darkValue
			? lightValue
			: `\n\tlight ☀️: ${lightValue} / ${formatToken(lightToken)}\n\tdark 🌙: ${darkValue} / ${formatToken(darkToken)}`;
	return `var(${variableName}, /* ${comment} */)`;
}

export function getTailwindPluginTheme() {
	const tw3Theme = {
		fontFamily: tailwindFormattedTheme.fontFamily.reduce(
			(acc, [variable, value]) => {
				acc[variable.replace("--font-", "")] =
					value + ` /* ${getCssVariable(variable).declaration} */`;
				return acc;
			},
			{},
		),
		colors: tailwindFormattedTheme.primitiveColors.reduce(
			(acc, [variable, value]) => {
				const variableName = variable.replace("--", "");
				const parts = variableName.split("-");
				const shade = parts.pop();
				const color = parts.join("-");
				acc[color] ??= {};
				if (color === shade) {
					acc[color] = value + ` /* ${getCssVariable(variable).declaration} */`;
				} else {
					acc[color][shade] =
						value + ` /* ${getCssVariable(variable).declaration} */`;
				}
				return acc;
			},
			{},
		),
		backgroundColor: tailwindFormattedTheme.backgroundColors.reduce(
			(acc, [variable]) => {
				acc[variable.replace("--color-", "").replace("-background", "")] =
					getThemedValue(variable);
				return acc;
			},
			{},
		),
		borderColor: tailwindFormattedTheme.borderColors.reduce(
			(acc, [variable]) => {
				acc[variable.replace("--color-", "").replace("-border", "")] =
					getThemedValue(variable);
				return acc;
			},
			{},
		),
		textColor: tailwindFormattedTheme.foregroundIconColors.reduce(
			(acc, [variable]) => {
				acc[variable.replace("--color-", "").replace("-foreground", "")] =
					getThemedValue(variable);
				return acc;
			},
			{},
		),
		fill: tailwindFormattedTheme.lightThemeColors.reduce((acc, [variable]) => {
			if (
				variable.includes("-border") ||
				variable.includes("-foreground") ||
				variable.includes("-icon")
			) {
				acc[variable.replace("--color-", "")] = getThemedValue(variable);
			}
			return acc;
		}, {}),
		stroke: tailwindFormattedTheme.lightThemeColors.reduce(
			(acc, [variable]) => {
				if (
					variable.includes("-border") ||
					variable.includes("-foreground") ||
					variable.includes("-icon")
				) {
					acc[variable.replace("--color-", "")] = getThemedValue(variable);
				}
				return acc;
			},
			{},
		),
		screens: tailwindFormattedTheme.breakpoints.reduce(
			(acc, [variable, value]) => {
				acc[variable.replace("--breakpoint-", "")] =
					value + ` /* ${variable} */`;
				return acc;
			},
			{},
		),
		blur: tailwindFormattedTheme.backdropFilters.reduce(
			(acc, [variable, value]) => {
				const key = getCssVariable(variable).declaration;
				acc[key.replace("--blur-", "")] = processValue(value) + `/* ${key} */`;
				return acc;
			},
			{ DEFAULT: getValue("effects", "--backdrop-filters-surface-glass-blur") },
		),
		borderRadius: tailwindFormattedTheme.borderRadius.reduce(
			(acc, [variable, value]) => {
				acc[variable.replace("--radius-", "")] =
					processValue(value, {
						includeComment: false,
					}) + ` /* ${variable} */`;
				return acc;
			},
			{
				DEFAULT: getValue("primitives-size", "--radius-md", {
					includeCalcComment: false,
				}),
				"density-xl": getValue("density-standard", "--radius-density-xl"),
			},
		),
		borderWidth: tailwindFormattedTheme.borderWidth.reduce(
			(acc, [variable, value]) => {
				const cssVariable = getCssVariable(variable);
				acc[cssVariable.declaration.replace("--border-width-", "")] =
					processValue(value, { includeComment: false }) +
					` /* ${cssVariable.declaration} */`;
				return acc;
			},
			{
				DEFAULT: getValue("primitives-size", "--border-width-1", {
					includeCalcComment: false,
				}),
			},
		),
		boxShadow: tailwindFormattedTheme.shadows.reduce(
			(acc, [variable, value]) => {
				const key = getCssVariable(variable).declaration;
				acc[key.replace("--shadow-", "")] =
					processValue(value, { includeComment: false }) + ` /* ${key} */`;
				return acc;
			},
			{
				DEFAULT: getValue("effects", "--shadows-elevation-md", {
					includeCalcComment: false,
				}),
			},
		),
		fontSize: tailwindFormattedTheme.fontSize.reduce(
			(acc, [variable, value]) => {
				const key = getCssVariable(variable).declaration;
				acc[key.replace("--text-", "")] = processValue(value) + ` /* ${key} */`;
				return acc;
			},
			{ base: getValue("primitives-typography", "--font-size-14") },
		),
		fontWeight: tailwindFormattedTheme.fontWeight.reduce(
			(acc, [variable, value]) => {
				const key = getCssVariable(variable).declaration;
				acc[key.replace("--font-weight-", "")] =
					processValue(value) + ` /* ${key} */`;
				return acc;
			},
			{},
		),
		lineHeight: tailwindFormattedTheme.lineHeight.reduce(
			(acc, [variable, value]) => {
				const key = getCssVariable(variable).declaration;
				acc[key.replace("--leading-", "")] =
					processValue(value) + ` /* ${key} */`;
				return acc;
			},
			{},
		),
		letterSpacing: tailwindFormattedTheme.letterSpacing.reduce(
			(acc, [variable, value]) => {
				acc[variable.replace("--tracking-", "")] = value;
				return acc;
			},
			{},
		),
		spacing: tailwindFormattedTheme.semanticSizes.reduce(
			(acc, [key]) => {
				const {
					"density-standard": standardToken,
					"density-compact": compactToken,
					"density-spacious": spaciousToken,
				} = getAllValues(key);
				const cssVariable = getCssVariable(key);
				acc[key.replace("--spacing-", "")] =
					`var(${cssVariable.declaration}, /*\n\tstandard: ${processValue(standardToken, { includeComment: false })}\n\tcompact: ${processValue(compactToken, { includeComment: false })}\n\tspacious: ${processValue(spaciousToken, { includeComment: false })}\n */)`;
				return acc;
			},
			{
				DEFAULT: "4px",
			},
		),
		animation: tailwindFormattedTheme.animation,
		transitionDuration: tailwindFormattedTheme.transitionDuration,
		transitionTimingFunction: tailwindFormattedTheme.transitionTimingFunction,
	};

	return { extend: tw3Theme };
}

export function getTailwindCssTheme() {
	// Tailwind 4 generates a spacing scale, we only need to provide the "base" to scale from and
	// any supplemental spacing values we want to add.
	const BASE_VALUE = kuiDesignTokens["primitives-size"]["--size-100"];
	const primitives = [
		// colors
		...tailwindFormattedTheme.primitiveColors.map(processThemeEntries),
		// typography
		...tailwindFormattedTheme.fontFamily,
		...tailwindFormattedTheme.fontSize.map(processThemeEntries),
		...tailwindFormattedTheme.fontWeight.map(processThemeEntries),
		...tailwindFormattedTheme.lineHeight.map(processThemeEntries),
		...tailwindFormattedTheme.letterSpacing.map(processThemeEntries),
		// sizes
		["--spacing", BASE_VALUE],
		...tailwindFormattedTheme.breakpoints.map(processThemeEntries),
		...tailwindFormattedTheme.borderWidth.map(processThemeEntries),
		...tailwindFormattedTheme.borderRadius.map(processThemeEntries),
		// effects
		...tailwindFormattedTheme.shadows.map(processThemeEntries),
		...tailwindFormattedTheme.backdropFilters.map(processThemeEntries),
		...Object.entries(tailwindFormattedTheme.animation).map(([key, value]) => [
			`--animate-${key}`,
			value,
		]),
		...Object.entries(tailwindFormattedTheme.transitionDuration).map(
			([key, value]) => [`--transition-duration-${key}`, value],
		),
		...Object.entries(tailwindFormattedTheme.transitionTimingFunction).map(
			([key, value]) => [`--ease-${key}`, value],
		),
	];
	const lightTheme = tailwindFormattedTheme.lightThemeColors
		.map(processThemeEntries)
		.sort();
	const darkTheme = getFromTheme("theme-dark").map(processThemeEntries).sort();
	const darkThemeMap = Object.fromEntries(darkTheme);
	const standardDensity =
		getFromTheme("density-standard").map(processThemeEntries);

	const DARK_SELECTOR = "@custom-variant dark (&:where(.nv-dark, .nv-dark *));";

	const themeCss = `
${DARK_SELECTOR}

/* Static Theme Properties */
@theme {
  ${primitives.map(([token, value]) => `${token}: ${value};`).join("\n")}
}

/* Themed Properties - do not inline */
@theme {
  ${lightTheme.map(([token, value]) => `${token}: ${value}; /* .nv-dark: ${darkThemeMap[token]} */`).join("\n")}
	${standardDensity.map(([token, value]) => `${token}: ${value};`).join("\n")}
}
`;

	return {
		primitives,
		lightTheme,
		darkTheme,
		densityCompact: getFromTheme("density-compact").map(processThemeEntries),
		densitySpacious: getFromTheme("density-spacious").map(processThemeEntries),
		densityStandard: standardDensity,
		themeCss,
	};
}

/********************
 * Utility functions
 ********************/

/**
 * Converts values from the design tokens over to the format that Tailwind expects.
 */
export function processThemeEntries([token, value]) {
	// Regex to find all instances of CSS variables (--anything)
	const TOKENS_REGEX = /--[a-zA-Z0-9-]+/g;
	return [
		getCssVariable(token).declaration,
		typeof value === "string"
			? // Use regex to find all instances of CSS variables (--anything) and replace them with var()
				// references to handle nested tokens i.e. blur(var(--size-100))
				value.replace(TOKENS_REGEX, (match) => getCssVariable(match).reference)
			: value,
	];
}

/**
 * Use this function get the value of a variable from the design tokens with a CSS comment describing
 * the value for use in the Tailwind intellisense plugin.
 * @param {keyof KuiDesignTokens} collection
 * @param {keyof KuiDesignTokens["density-standard"] | keyof KuiDesignTokens["effects"] | keyof KuiDesignTokens["primitives-color"] | keyof KuiDesignTokens["primitives-size"] | keyof KuiDesignTokens["primitives-typography"] | keyof KuiDesignTokens["theme-light"]} variable
 * @param {} [options]
 * @returns {string}
 */
function getValue(
	collection,
	variable,
	{ includeComment = true, includeCalcComment = true } = {},
) {
	const value = kuiDesignTokens[collection][variable];
	if (!value) {
		throw new Error(`${variable} is not a valid variable for ${collection}`);
	}
	return (
		processValue(value, {
			includeComment: includeCalcComment,
		}) +
		(includeComment ? ` /* ${getCssVariable(variable).declaration} */` : "")
	);
}

const TOKENS_REGEX = /--[a-zA-Z0-9-]+/g;
function processValue(val, { includeComment = true } = {}) {
	const value = val.toString();
	if (value.includes("--size-")) {
		return value.replace(TOKENS_REGEX, (match) => {
			const variable = getCssVariable(match);
			if (includeComment && variable.calcValue) {
				return `${variable.reference} /* ${variable.calcValue} */`;
			} else return variable.reference;
		});
	}
	if (value.startsWith("--")) {
		return getCssVariable(value).reference;
	}
	return value;
}
