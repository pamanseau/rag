/**
 * This is a CJS script because tailwindcss/plugin & /nesting does not support ESM.
 */
module.exports = {
	plugin: require("tailwindcss/plugin"),
};
