// @ts-check
import { createLogger } from "./logger.js";

/**
 * @typedef {keyof typeof import("../dist/themes/all.js").default} Theme
 * @typedef {'--default' | '--prefersdark' | '--exclude'} Flag
 * @typedef {`${Theme}${` ${Flag}` | ""}`} ThemeFlag
 */

/**
 * @type {ThemeFlag[]}
 */
const DEFAULT_THEMES = [
	"nv-light --default",
	"nv-dark",
	"nv-density-standard --default",
	"nv-density-compact",
	"nv-density-spacious",
];

/**
 * @param {(options: PluginOptions & { logger: ReturnType<typeof createLogger> }) => any} pluginFn
 * @param {(options: PluginOptions & { logger: ReturnType<typeof createLogger> }) => any} configFn
 */
export const makeTwPlugin = (pluginFn, configFn) => {
	/**
	 * @typedef {{
	 *  root?: string;
	 *  ["default-themes"]?: ThemeFlag[] | string;
	 *  themes?: ThemeFlag[] | string;
	 *  ["log-level"]?: 'debug' | 'info' | 'silent';
	 *  ["disable-component-utilities"]?: boolean;
	 * }} PluginOptions
	 *
	 * @param {PluginOptions} [options]
	 */
	const optionsFn = (options) => {
		const logger = createLogger(options?.["log-level"]);
		const withDefaults = {
			...(options || {}),
			root: options?.root || ":root",
			themes: resolveThemes(
				options?.themes,
				options?.["default-themes"] || DEFAULT_THEMES,
			),
			logLevel: options?.["log-level"] || "info",
			logger,
			disableComponentUtilities:
				options?.["disable-component-utilities"] || false,
		};
		return {
			handler: pluginFn(withDefaults),
			config: configFn(withDefaults),
		};
		/**
		 * This function will resolve user input themes and the default themes to a list of themes to load
		 * in the tailwind plugin.
		 *
		 * By default the plugin will load in DEFAULT_THEMES - light theme as default, dark theme with prefers
		 * dark, and the three density themes.
		 *
		 * When users provide a theme that exists in DEFAULT_THEMES, their definition will override the default.
		 *
		 * @param {ThemeFlag[] | string | undefined} argInputThemes A comma separated list of themes. Can include flags like
		 * `--default`, `--prefersdark`, and `--exclude`.
		 * @param {ThemeFlag[] | string} argDefaultThemes The default themes to load if no user input is provided.
		 * @returns {ThemeFlag[]} The themes to load in the tailwind plugin
		 */
		function resolveThemes(argInputThemes, argDefaultThemes) {
			const defaultThemes = Array.isArray(argDefaultThemes)
				? argDefaultThemes.map((theme) => theme.toLowerCase())
				: argDefaultThemes.toLowerCase().split(", ");
			if (!argInputThemes) {
				logger.debug(
					`No user input themes provided, using default themes ${defaultThemes.join(", ")}`,
				);
				return /** @type {ThemeFlag[]} */ (defaultThemes);
			}
			const userInputThemes = Array.isArray(argInputThemes)
				? argInputThemes.map((theme) => theme.toLowerCase())
				: argInputThemes.toLowerCase().split(", ");
			// userInputThemes will contain either "overrides" for the default themes, or "excludes" for the default themes
			const { excludes, overrides } = userInputThemes.reduce(
				(acc, theme) => {
					const [themeName, ...flagParts] = theme.split(" ");
					const flag = flagParts.join(" ");
					if (!flag.includes("--exclude")) {
						acc.overrides.push(theme);
					}
					acc.excludes.add(themeName);
					return acc;
				},
				{ excludes: new Set(), overrides: /** @type {string[]} */ ([]) },
			);
			logger.debug(
				`Excluding ${[...excludes.keys()].join(", ")} from default themes\nApplying overrides: ${overrides.join(", ")}`,
			);
			return /** @type {ThemeFlag[]} */ ([
				...overrides,
				...defaultThemes.filter((theme) => !excludes.has(theme)),
			]);
		}
	};
	// for tailwind to recognize this as an options function
	optionsFn.__isOptionsFunction = true;
	return optionsFn;
};
