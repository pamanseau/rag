const LOG_LEVELS = /** @type {const} */ ({
	silent: 0,
	info: 1,
	debug: 2,
});

/**
 * @param {keyof typeof LOG_LEVELS} [currentLevel]
 */
export function createLogger(currentLevel = "info") {
	const level = LOG_LEVELS[currentLevel];
	return {
		info: (...args) => {
			if (level >= LOG_LEVELS.info) {
				console.info("@kui/foundations:", ...args);
			}
		},
		debug: (...args) => {
			if (level >= LOG_LEVELS.debug) {
				console.log("@kui/foundations [DEBUG]:", ...args);
			}
		},
	};
}
