import fs from "fs";
import { transform } from "lightningcss";
import postcss from "postcss";
import postcssJs from "postcss-js";
import { compile } from "tailwindcss";

/**
 * Loosen @property syntax for Tailwind gradient color variables so they accept
 * composite values used by Tailwind v3 (e.g. "<color> var(--tw-gradient-*-position)").
 *
 * This rewrites only the syntax line inside the three gradient color @property blocks:
 *  - --tw-gradient-from
 *  - --tw-gradient-via
 *  - --tw-gradient-to
 * to use a wildcard ("*") instead of the stricter "<color>" type.
 * @todo: Revisit this solution for other @property blocks - do we need to make this more or less
 * restrictive?
 *
 * @param {string} css
 * @returns {string}
 */
function relaxGradientAtPropertySyntax(css) {
	return css.replace(
		/(@property\s+--tw-gradient-(?:from|via|to)\s*\{[\s\S]*?\bsyntax:\s*)"[^"]+"/g,
		'$1"*"',
	);
}

function getThemeToCompileComponentCss() {
	const themeCss = fs.readFileSync("theme/index.css", "utf-8");
	const tailwindDefaultTheme = fs.readFileSync(
		"node_modules/tailwindcss/theme.css",
		"utf-8",
	);
	return tailwindDefaultTheme + "\n" + themeCss;
}
const startTag = "@layer blockStart;";
const endTag = "@layer blockEnd;";
/**
 * @template {boolean} [TIncludeProperties=false]
 * Compiles Tailwind CSS to raw CSS.
 * @param {{ css?: never; inputFile: string; includeProperties?: TIncludeProperties } | { css: string; inputFile?: never;  includeProperties?: TIncludeProperties }} params
 * @returns {TIncludeProperties extends true ? Promise<{ css: string; properties: string }> : Promise<string>} The compiled CSS
 */
export async function compileCss({ css, inputFile, includeProperties }) {
	if (!css && !inputFile) {
		throw new Error(
			"[compileCss] Received empty CSS to compile - make sure your CSS has content.",
		);
	}
	if (inputFile && !fs.existsSync(inputFile)) {
		throw new Error(`[compileCss] Input file ${inputFile} does not exist`);
	}
	const [cssToProcess, tailwindTheme] = await Promise.all([
		inputFile ? fs.promises.readFile(inputFile, { encoding: "utf-8" }) : css,
		getThemeToCompileComponentCss(),
	]);
	// cssToProcess contains @reference statements for Tailwind Intellisense - we need to strip them
	// out because we manually inject the theme into the compiled CSS.
	const cleanedCss = cssToProcess.replace(/@reference.*/g, "");
	const cssBlock = `
    ${tailwindTheme}
        ${startTag}
        ${cleanedCss}
        ${endTag}
  `;
	const compiledContent = await compile(cssBlock, {}).then((result) =>
		result.build([]),
	);

	const startIndex = compiledContent.indexOf(startTag);
	const endIndex = compiledContent.indexOf(endTag);
	if (startIndex === -1 || endIndex === -1 || endIndex <= startIndex) {
		throw new Error("[compileCss] Failed to find compiled code within blocks");
	}
	const rawMainContent = compiledContent
		.substring(startIndex + startTag.length, endIndex)
		.trim();
	/**
	 * Extract component properties from main content
	 * Components can have @layer properties blocks that should be moved to the properties section
	 */
	const componentProperties = [];
	let mainContent = rawMainContent;
	// Find and extract all @layer properties blocks with proper brace matching
	const layerPropertiesRegex = /@layer\s+properties\s*\{/g;
	let match;
	while ((match = layerPropertiesRegex.exec(rawMainContent)) !== null) {
		const startIndex = match.index;
		const openBraceIndex = rawMainContent.indexOf("{", startIndex);
		if (openBraceIndex === -1) continue;
		// Find the matching closing brace
		let braceCount = 1;
		let endIndex = openBraceIndex + 1;
		while (braceCount > 0 && endIndex < rawMainContent.length) {
			const char = rawMainContent[endIndex];
			if (char === "{") {
				braceCount++;
			} else if (char === "}") {
				braceCount--;
			}
			endIndex++;
		}
		if (braceCount === 0) {
			// Extract the complete @layer properties block
			const propertiesBlock = rawMainContent.substring(startIndex, endIndex);
			componentProperties.push(propertiesBlock);
		}
	}
	// Remove @layer properties blocks from main content
	if (componentProperties.length > 0) {
		let cleanedContent = rawMainContent;
		for (const propertiesBlock of componentProperties) {
			cleanedContent = cleanedContent.replace(propertiesBlock, "");
		}
		mainContent = cleanedContent.trim();
	}
	/**
	 * Content after the core component CSS is CSS @property declarations, or @keyframes for animations.
	 * These only need to be included once - we strip them out of the main content for the CSS return
	 * value and instead provide a mechanism to get only them returned.
	 *
	 * Later these are packaged up into the base.css file that all consumers import. This includes a
	 * trivial amount of additional CSS to base.css, but ensures we have all CSS properties defined
	 * and any necessary "core" definitions like @keyframes for animations.
	 */
	const baseProperties = compiledContent
		.substring(endIndex + endTag.length)
		.trim();
	// @todo: Revisit this solution for other @property blocks
	const properties = relaxGradientAtPropertySyntax(
		componentProperties.length > 0
			? baseProperties + "\n\n" + componentProperties.join("\n\n")
			: baseProperties,
	);
	if (includeProperties) {
		return {
			css: compiledContent,
			properties: properties,
		};
	}
	return mainContent;
}
/**
 * Minifies given CSS using LightningCSS.
 * @param {({ css?: never; inputFile: string } | { css: string; inputFile?: never }) & { overwrite?: boolean }} params
 * @returns {Promise<string>} The minified CSS
 */
export async function minifyCss({ css, inputFile, overwrite }) {
	if (!css && !inputFile) {
		throw new Error(
			"[minifyCss] Received empty CSS to minify - make sure your CSS has content.",
		);
	}
	if (inputFile && !fs.existsSync(inputFile)) {
		throw new Error(`[minifyCss] Input file ${inputFile} does not exist`);
	}
	const cssToProcess =
		css || (await fs.promises.readFile(inputFile, { encoding: "utf-8" }));
	const UNICODE_ESCAPE = "_UNICODE_ESCAPE_TEMP_";
	const { code } = transform({
		filename: inputFile,
		code: Buffer.from(cssToProcess),
		minify: true,
		visitor: {
			Declaration(decl) {
				function replaceWithUnicodeEscape(str) {
					return [...str]
						.map((char) => {
							// Check if the character is non-ASCII
							if (char.codePointAt(0) > 0x7f) {
								// Get the Unicode code point and convert to hexadecimal
								const codePoint = char.codePointAt(0).toString(16);
								// Add placeholder
								return `${UNICODE_ESCAPE}${codePoint}`;
							} else {
								// Return ASCII characters as-is
								return char;
							}
						})
						.join("");
				}
				if (decl.property === "custom" && decl.value.name === "content") {
					decl.value.value = decl.value.value.map((x) => {
						if (x.value.value) {
							let unicodeContent = replaceWithUnicodeEscape(x.value.value);
							return {
								...x,
								value: {
									...x.value,
									value: unicodeContent,
								},
							};
						} else {
							return x;
						}
					});
					return decl;
				}
				// If not the content property or no special handling needed, return the original declaration
				return decl;
			},
		},
	});
	const cleanedCode = code.toString().replaceAll(UNICODE_ESCAPE, "\\");
	if (inputFile && overwrite) {
		await fs.promises.writeFile(inputFile, cleanedCode);
	}
	return cleanedCode;
}
/**
 * Converts CSS to a JS object - returns it as a string or object
 * @param {({ css?: never; inputFile: string } | { css: string; inputFile?: never }) & { as?: "object" | "string" }} params
 * @returns {Promise<string | object>} The converted CSS
 */
export async function cssToJs({ css, inputFile, as = "object" }) {
	if (!css && !fs.existsSync(inputFile)) {
		throw new Error(`Input file ${inputFile} does not exist`);
	}
	const cssToProcess =
		css || (await fs.promises.readFile(inputFile, { encoding: "utf-8" }));
	const objectifiedCss = postcssJs.objectify(postcss.parse(cssToProcess));
	if (as === "object") {
		return objectifiedCss;
	} else {
		return `export default ${JSON.stringify(objectifiedCss, null, 2)};\n`;
	}
}
