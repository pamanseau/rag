import zlib from "zlib";

/**
 * Get the size of a file in bytes, kilobytes, or megabytes
 * @param {string} contents - The contents of the file
 * @param {{ format?: "bytes" | "kb" | "mb" }} [options] - The format of the size to return
 * @returns {{ compressed: number, original: number }} - The size of the file in the specified format
 */
export function getFileSize(contents, { format = "bytes" } = {}) {
	const compressed = zlib.gzipSync(contents).length;
	const original = contents.length;

	if (format === "kb") {
		return {
			compressed: compressed / 1024,
			original: original / 1024,
		};
	}

	if (format === "mb") {
		return {
			compressed: compressed / 1024 / 1024,
			original: original / 1024 / 1024,
		};
	}

	return {
		compressed: compressed,
		original: original,
	};
}
