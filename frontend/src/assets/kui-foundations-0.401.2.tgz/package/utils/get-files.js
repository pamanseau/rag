import fs from "fs";

/**
 * Get all files in a directory
 * @param {string} dir - The directory to get files from
 * @param {string} fileType - The file type to filter by
 * @returns {string[]} - An array of file paths including the directory
 */
export function getFiles(dir, fileType = ".css") {
	if (!fs.existsSync(dir)) {
		return [];
	}
	return fs
		.readdirSync(dir)
		.filter((f) => f.includes(fileType))
		.map((f) => `${dir}/${f}`);
}
