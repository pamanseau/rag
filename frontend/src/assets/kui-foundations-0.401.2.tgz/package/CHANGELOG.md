# @kui/foundations

## 0.401.2

### Patch Changes

- aff869c: apply hover background colors
- aff869c: Add base border to all kind cards except `float`

## 0.401.1

### Patch Changes

- 9d615ec: Small fixes for VerticalNav gradient and Tab/Pagination stroke animations. Animates VerticalNav accordion gradient on open and close if there is an active sublink inside, and changes adds a before pseudo element for Tab/Pagination to allow for Pagination arrow tabbing (and to fix exit animation for stroke).
- 4596d55: Adds NDL alignment updates for the Switch component; also implements motion.

## 0.401.0

### Minor Changes

- 3759032: adds w-auto to the svg in the spinner component for safari compatibility

## 0.400.1

### Patch Changes

- 150247b: fix --tw gradient properties in tw version 3

## 0.400.0

### Minor Changes

- 1956c2d: !! BREAKING CHANGE !! - hoists form-field params on form elements to simplify usage of form-field component, adds default values to use-controllable-state preventing toggling between controlled/uncontrolled, and fixes a datepicker issue preventing status styling from applying
- 776da6f: !! BREAKING CHANGE !! Density semantic sizes are being prefixed with "density".

  This is to increase awareness about when to use semantic sizes and also to ensure users are aware that the size they're using is theme responsive, and also to remove places where we are overriding the Tailwind defaults in an unexpected way. This affects all spacing related Tailwind utilities like:

  - `gap`
  - `max-w`, `w`, `min-w`
  - `max-h`, `h`, `min-h`
  - `p`, `py`, `px`, `pt`, `pb`, `pl`, `pr`
  - `m`, `my`, `mx`, `mt`, `mb`, `ml`, `mr`
  - `top`, `right`, `bottom`, `left`, `inset`

  You will need to update these usages to use the new semantic sizes, otherwise they will fallback to the default Tailwind size for that semantic size **which is different and likely will not look as designed**.

  To update, you can do a find and replace using the following regex as a guide:

  Search:

  ```regex
  \b(gap|(?:max-|min-)?[wh]|(?:p|m)(?:[xy]|[trbl])?|top|right|bottom|left|inset|space-(?:x|y)(?:-[trbl])?)-(xs|sm|md|lg|[2-5]?xl)\b
  ```

  Replace:

  ```regex
  $1-density-$2
  ```

  That should help find and replace Tailwind classes.

  Many of our React components are also affected by this change - `Flex`, `Grid`, `GridItem`, `Block`, `Stack`, `Inline`, and `Divider`.

  For these components the `gap` prop will now throw a TS error on non-prefixed semantic sizes, but it will continue to work despite that for backwards compatibility. The `spacing`, `spacingX`, `spacingY`, `spacingTop`, `spacingRight`, `spacingBottom`, and `spacingLeft` props are all deprecated and will be removed in the next major version. Instead replace with the new `padding`, `paddingX`, `paddingY`, `paddingTop`, `paddingRight`, `paddingBottom`, and `paddingLeft` props which require the prefixed semantic sizes.

  ```tsx
  <Flex
  -  gap="xs"
  +  gap="density-xs"
  />
  ```

- 424a5ca: !! BREAKING CHANGE !! Update `@kui/foundations` Tailwind plugin - rename `nv-theme-dark` and `nv-theme-light` to `nv-dark` and `nv-light` to align with the CSS class names used to activate them for consistency.

  To migrate, update `nv-theme-dark` and `nv-theme-light` to `nv-dark` and `nv-light` respectively in your plugin usage.

  ```css
  @plugin "@kui/foundations" {
  -  themes: nv-theme-dark --prefers-dark;
  +  themes: nv-dark --prefers-dark;
  }
  ```

## 0.307.1

### Patch Changes

- 053f704: Fix broken menu overflow components - Dropdown, Combobox, and Select do not overflow when there are too many items. Fixing that

## 0.307.0

### Minor Changes

- 8cc1adf: Update Table component - add TableToolbar and TableBulkActionToolbar components, add `hoverableRows` prop, add selected state for rows, simplify base component API, and update docs.

### Patch Changes

- 6742ca4: Add simple animations for Tooltips, Popovers, Side Panels, and Modals. Also added a motion-specific CSS file for relevant/shared properties.
- a684630: Update color tokens after Button color changes. Add motion to Button component.
- 3c549ed: adds motion to foundations plugin base
- 5484b4c: Fix issue in Tabs HorizontalNav that causes flashing due to active and [data-state="active"] states using the same styles.
- 8cc1adf: Fix Menu Item issue where MenuItem children could not take full width
- 8cc1adf: Fix StatusMessage header to center text as well since it's already center positioned
- e84febc: restructure docs, updates modal overlay styling, and exposes an "onOpenAutoFocus" prop to modal and side panel
- f0c4e8b: Add motion to VerticalNav, HorizontalNav, Pagination, Tabs, and Anchor components.
- 000db54: Add motion to all input elements (TextInput, TextArea, FormField, Dropdown, Combobox, Select). Includes border animation and menu animations.
- 8cc1adf: Limit popover height to the available height for it in the viewport"

## 0.306.0

### Minor Changes

- e9fcc29: Update StatusMessage - add mx-auto to root to ensure it's always centered, and set media font size as part of the result size to ensure consistency. Also handle footer styling in the component so `slotFooter` doesn't require another component to work

### Patch Changes

- 9b08580: Add shared configs for CSS and Tailwind property processing.
- f771087: Adds motion to the Accordion component and introduces a new AnimatedChevron component to be used in accordion- and menu-related components that interpolates between ChevronUp and ChevronDown states.

## 0.305.0

### Minor Changes

- e6400b3: TextArea new features: add `resizeable` prop to control the text area's resize behaviour. By default, the text area will not be resizeable(`resizeable={undefined}`).

  - `resizeable="manual"` will be manually resizeable only vertically
  - `resizeable="auto"` will auto grow to fit the content up to `--max-auto-height` (400px by default). Set `--max-auto-height` to control the max height.

### Patch Changes

- e6400b3: Update Avatar to not shrink
- e80f5d7: add search to the docs site

## 0.304.0

### Minor Changes

- 8a3a909: add gap-[inherit] to tabs

### Patch Changes

- 43ace03: fix spinner description height to match content

## 0.303.0

### Minor Changes

- 1f70535: add kui and sans licenses to foundations css and react

## 0.302.1

### Patch Changes

- a9d520f: add bold text to vertical nav sublink
- 138caae: Add simple transition on hover and click for Tags.
- 2441e80: Update ProgressBar Indicator to be rounded to align with designs
- 77e4099: finalizes the docs migration to MDX and resolves a side-panel styling issue when modal={true}

## 0.302.0

### Minor Changes

- 11c25fb: Add `density` prop to density aware components for overriding ThemeProvider density values and setting density quickly.

  - `Card`
  - `Modal`
  - `PageHeader`
  - `Panel`
  - `SidePanel`
  - `Table`
  - `Tag`

- 030f58e: Add `indeterminate` kind of `ProgressBar` - thank you @mschwab :)
- 11c25fb: Override `align` property for `TableDataCell` and `TableHeaderCell` to use CSS to control alignment. Also add `align` property to `TableRoot`, `TableHead`, `TableBody`, and `TableRow` to control alignment on whatever level is necessary.

  Prefer `children` over `slotContent` and `slotHeader` for base `Table` component, but continue to support `slotContent` and `slotHeader` for backwards compatibility.

- 11c25fb: !! BREAKING CHANGE !! Update `Menu.size` to `Menu.density` and use density spacing instead of fixed padding/font sizes
- 18acc28: !! BREAKING CHANGE !! Remove italic Text kinds. You can already add italic styles with the italic property and it's redundant
- 11c25fb: BREAKING CHANGE - Update `Skeleton` height to be `1.3em` so it will set its height based on the containers font size, rather than a fixed height that requires manual height setting.
- 25f8fdf: Feature: Combobox will render the filterValue by default instead of value when filterValue is provided
- 11c25fb: Tabs.items prop will now use `children` instead of `slotTrigger` for items, however `slotTrigger` is still supported for backwards compatibility.

  Additionally `items` can also be passed `asChild` now to render custom elements as tab triggers.

### Patch Changes

- 29c03d8: Add animation to the Checkbox component, so it draws and erases the checkmark on click. Also, start adding tokens for motion (easing and duration).
- 11c25fb: Add `--nv-scrollbar-color` CSS variable for aligning scrollbars with supported platforms
- 23e38ba: Add simple transition on hover and click for Avatar component.
- 18acc28: Update Text.css ordering so that modifier classes can override "kind" classes
- 1e1870c: Update underlying dependecies to latest
- d605429: Add motion to radios to have them iris in and out on click.

## 0.301.1

### Patch Changes

- 3bc22c6: add medium elevation to floating page header
- 4e06113: Bump axios and other dependencies for security

## 0.301.0

### Minor Changes

- f411f15: Added icon to checked state for single Select; also updated padding and colors for Menu and Select components. Refactored MenuItems to use a generic base component with a slot for additional functionality.
- f411f15: Added checkmark for single select menu items; also adjusted padding and colors for SelectItems and MenuItems. Refactored MenuItems to use a generic base that can be customized via slotIcon.

## 0.300.0

### Minor Changes

- 809492a: !! BREAKING CHANGE !! Update `Select`, `Combobox`, and `Menu` to use `children/value` over `slotText/textValue` props. We hope this will provide a more consistent API across our components and also more closely match what our consumers are used to. Also rename `matchValue` to `filterValue` to make it clearer that that value is used for filtering.
- e0bbd7c: Update the text tokens to align with new NDL styles
- 809492a: !! BREAKING CHANGE !! Update `Combobox` visually - instead of a select with a nested menu and searchbar, it's now more like a text input with an associated menu. Significant API changes were also made - specifically we better distinguish between the value of the combobox(i.e. the value of the input) and the selected values(i.e. the values of the items in the menu). Our props have been updated to be clearer on this, and we've noted these in the JSDoc so it should appear in the intellisense in your IDE.

### Patch Changes

- 809492a: Fix gray solid tag hover colour
- 809492a: Fix issue in Button where icon colors were being overridden by parent styles
- 1326208: Updated spacing and background colors for TextInput and TextArea components, and added width resizing for TextArea.
- e3888a9: Fix base path and content to point to new repo in documentation
- 1d45b32: add main, module, and types fields to package.json
- 809492a: Add new Checkbox class to left align label instead of relying on flex styles

## 0.203.0

### Minor Changes

- 89fed51: Fix TextInput disabled placeholder style
- 89fed51: Update RadioGroup

  - Rename `options` to `items` for consistency with other components.
  - Rename `item.slotLabel` to `item.children` - this should help clear up what the prop is
  - add `items.danger` to set specific items as danger state
  - add `showIndicator` to control indicator visibility for custom items

- 89fed51: Update Dropdown trigger to use normal button tertiary styles, and add a side offset to the dropdown content.

### Patch Changes

- 89fed51: Update Menu to support strings as items, and to allow for `danger` radio items.
- 8ed5f03: Update build script to use vfe build-tools

## 0.202.0

### Minor Changes

- 8c09145: !! BREAKING CHANGE !! - Delete deprecated colour tokens and font size tokens

  For font size tokens, the following changes were made:

  | Before    | After   |
  | --------- | ------- |
  | text-50   | text-10 |
  | text-100  | text-12 |
  | text-200  | text-14 |
  | text-300  | text-16 |
  | text-500  | text-20 |
  | text-600  | text-24 |
  | text-800  | text-32 |
  | text-1200 | text-50 |

  For colour tokens, see the [color tokens](https://virtual-front-end-initiative.gitlab-master-pages.nvidia.com/kaizen-ui-foundations/kaizen-ui/fundamentals/color) page.

### Patch Changes

- 111702d: Updated colors and border width for Radio component
- bac6eb0: Updated colors and border width for Checkbox component.
- ac30da0: Removed border styling for progress bar and changed bar heights to align with Figma specifications.
- 4e5e38e: Updated border styles for Avatar component; adjusted type and changed border styling to add a pseudo element in order to avoid image scaling. Also updated docs site to include info about the outline vs solid "kind" prop.

## 0.201.0

### Minor Changes

- d5599e9: extracts datepicker input and datepicker calendar dropdown to separate composable components for more flexibility and composability
- eac1800: !! BREAKING CHANGE !! Update Hero to use new text styles to align with NVIDIA Design Language. Remove `align` prop - if consumers want to align content differently they can just use CSS. Added recipes to the documentation to help them with that.
- 532322a: Remove arrow from popover, set arrow to hidden by default for Tooltip.
- eac1800: !! BREAKING CHANGE !! Update Text component to use the new text utilities provided by design

### Patch Changes

- 532322a: Update tiny button padding

## 0.200.0

### Minor Changes

- 1007c93: !! BREAKING CHANGE !! Add new text utility functions - these utility functions will replace the old ones eventually which are now deprecated and will be removed before final release. The main breaking change in this change currently is that `--font-size-50` is now `50px` - previously it was `10px`.

  So any Tailwind utilities like `text-50` will need to be replaced with `text-10`.

  Additionally the `xxl` breakpoint is renamed to `2xl` for consistency across the design system. Update any selectors like `xxl:your-class` to `2xl:your-class`.

- 090aa16: Update documentation for Button, Tag, and Badge
- c8496fc: add datepicker component, minor refactor of context usage and input components, and formatting updates
- f50f055: Add select component to foundations library
- 090aa16: !! BREAKING CHANGE !! Update CTA components - Button, Tag, and Badge. Align their APIs to make them consistent - instead of using slotLeft/slotRight you can now just place icons directly within as children.

  Additionally these components no longer truncate text on overflow by default - instead we allow the user to determine the truncation behaviour and instead just wrap text. This preserves readability for long CTAs.

- b8e9e23: Update Tailwind classes to remove redundant property declarations i.e. instead of `border-input-base` it will now just be `border-input`.

  !! BREAKING CHANGE !!

  This also changes all of our CSS variables to use a new naming convention i.e. from `--color-surface-base-background` to `--background-color-surface-base`. For full details view the new `nv-light.css` file to see the names.

- 4675bf7: fixes minor focus behaviors in datepicker and adds docs for formfield
- 090aa16: Update CSS variables for Button, Tag, and Badge to remove "component" prefix and instead use a consistent API. i.e. `--border-color` instead of `--badge-border-color` and `--button-border`. This is so make it easier for consumers to build their own variants when necessary

### Patch Changes

- 1569559: Fix skeleton animation not working by adding missing `animation` CSS variable

## 0.106.0

### Minor Changes

- 2bdb55d: Update colour tokens for all components, and removed bold variant of badge due to low usage.

  Update designs for Tag, Tabs, Combobox, TextInput, TextArea, Tooltip, and Menu - consistent border radius across each now. Updated text styles.

### Patch Changes

- 2bdb55d: Fix combobox descenders being cut off

## 0.105.0

### Minor Changes

- 07ea989: Update button styling to align with brand

## 0.104.0

### Minor Changes

- 285d988: !! BREAKING CHANGE !! `@kui/react` component styles are no longer wrapped in a CSS layer. This has no impact on most of our users, except for our Tailwind v4 users. If you're using Tailwind v4 in conjunction with `@kui/react` you will want to disable CSS layers for Tailwind v4. Documentation here: https://virtual-front-end-initiative.gitlab-master-pages.nvidia.com/kaizen-ui-foundations/kaizen-ui/integrations/tailwind

### Patch Changes

- 20b4ebc: add support for @kui/react in react 19 apps

## 0.103.0

### Minor Changes

- a34eebf: Fix issue where @kui/react component styles could not be overridden by Tailwind. This also fixes an issues where base @kui/react styles were overriding padding/margin for anything built using Tailwind utilities, because it wasn't wrapped within a CSS layer

### Patch Changes

- a34eebf: Fix KUI11 utilities when used in Tailwind 4 projects
- a34eebf: Generate Tailwind properties for all components and inject them in base.min.css to ensure all required Tailwind properties are always present and automatically generated.
- a34eebf: Fix Tailwind intellisense in component CSS files by creating a Tailwind 4 CSS theme and referencing it from each stylesheet
- a34eebf: Fix an issue in menu.css where we were using the `&` operator in global CSS scope, resulting in a Tailwind plugin error where addUtilities was failing because "&" is an invalid selector
- a34eebf: Fix density token comment generation to remove comment within comment, which was causing broken CSS during development
- a34eebf: Fix text utilities to actually apply letter spacing from Figma

## 0.102.1

### Patch Changes

- cc7ebcd: render default menu size as medium
- 43198ab: Fix button and tag cursors to use pointer when enabled
- 43198ab: Fix gradient Card kind which previously was not rendering a mask image as expected

## 0.102.0

### Minor Changes

- bc76320: resolves an issue with controlled component state where forced values would not be respected, and exposes the forceMount prop to portaled components for animation control

### Patch Changes

- 3600dd9: adjust modal to no longer use transform for positioning

## 0.101.1

### Patch Changes

- 42b8107: Fix Page Header not taking full width in flex containers
- 42b8107: Adjust Horizontal Nav to use pseudo-element for selected state instead of border so text can be easily aligned

## 0.101.0

### Minor Changes

- 5068de1: Add kui build tools with license header script
- bd2a723: adds the form-field component and related documentation

### Patch Changes

- 0cf5986: Fix bug where "spacing-0.75" was being used as a CSS selector key without being escaped

## 0.100.0

### Minor Changes

- e97517d: PageHeader BREAKING change - remove unnecessary PageHeaderActions component in favour of just using the footer, refactor spacing prop to line up with other density spacing components
- e97517d: Panel BREAKING change - component to use our density tokens instead for spacing, and use the density themes to adjust spacing. Update spacing prop to "compact, standard, spacious" to match other components.
- e97517d: Avatar BREAKING change - update CSS class for xlarge and xxlarge to remove the extra dash i.e. "x-large -> xlarge" for consistency with our other components. The size prop was also updated to use this consistent formatting.
- e97517d: Upgrade @kui/foundations to use Tailwind 4 to compile styles and add Tailwind 4 support to the plugin
- ed476ed: Update `getColor` utility to just take the token name for easier use
- e97517d: Toast BREAKING change - replace ToastCloseButton with our Button component - no need for a second component that does the same thing.
- e97517d: Migrate from KUI design tokens to NVIDIA Design Language token system. This is a BREAKING change and changes the token names for many of our tokens.

  Font size tokens:
  | Before | After |
  | --- | --- |
  | xs | fs-50 |
  | sm | fs-100 |
  | md | fs-200 |
  | lg | fs-300 |
  | xl | fs-500 |
  | 2xl | fs-600 |
  | 3xl | fs-800 |
  | 4xl (48px) | fs-1200 (50px) |

  To migrate:

  ```
  // before
  - text-md
  // after
  + text-200
  ```

  Line height tokens:
  | Before | After |
  | --- | --- |
  | caps | caps (no change) |
  | text | lh-100 |
  | heading (1.20) | lh-125 (1.25) |
  | body | lh-150 |
  | - | lh-175 |

  To migrate:

  ```
  // before
  - leading-text
  // after
  + leading-lh-100
  ```

  Border width tokens:
  | Before | After |
  | --- | --- |
  | sm | border-1 |
  | md | border-2 |
  | lg | border-3 |
  | - | border-4 |

  To migrate:

  ```
  // before
  - border-sm
  // after
  + border-1
  ```

  Color tokens have been overhauled to use a more consistent naming convention of `color-<intent>-<property>`. So for disabled text for example, the token is now `color-disabled-foreground`, and the disabled border is `color-disabled-border`.

## 0.41.0

### Minor Changes

- c3acfcc: update table to use density tokens and rename roomy to spacious

### Patch Changes

- c3acfcc: update table defaults and types

## 0.40.0

### Minor Changes

- 9e4cf89: adds the pagination component and related styles

## 0.39.0

### Minor Changes

- 5bed578: Adjusted input styles with correct error tokens

### Patch Changes

- fbd8b18: sets the default radio-group width to fit the content

## 0.38.1

### Patch Changes

- 1391051: adjust side panel heading font size
- ba4c627: Fix @kui/foundations not pointing to the CJS file for main
- 91f03e1: Update Panel heading to take full component width

## 0.38.0

### Minor Changes

- 707fe8a: Create new `Group` utility component, and refactor ButtonGroup component to use Group under the hood
- 6b00524: Update primitive colors to new color palette from NDL

### Patch Changes

- 707fe8a: Refactor button css now that we don't need to use the classes as tailwind utilites. Also update button to truncate inner span children

## 0.37.1

### Patch Changes

- 7edae87: decreases the z-index of sidepanel to below modal

## 0.37.0

### Minor Changes

- cebebbd: Add Horizontal Nav component to Foundations

### Patch Changes

- 37e1b56: Support hero without media
- b34d844: update default card styles and remove unnecessary classes
- e787364: center checkbox label on the checkbox

## 0.36.2

### Patch Changes

- 9a2f310: Fix Combobox rendering bullets

## 0.36.1

### Patch Changes

- 857f6e5: resolves various accessibility issues in kui-react components
- 857f6e5: resolve various minor accessibility issues by setting default aria-labels and focus attributes

## 0.36.0

### Minor Changes

- 95b5390: Add Divider component and update Menu and Dropdown with Divider functionality

## 0.35.0

### Minor Changes

- 5a3babc: Update StatusMessage size class names for consistency, set medium as default size, and make size an optional prop

### Patch Changes

- 5a3babc: Update base dropdown to include href option for rendering links, and add max height to menu. Set Dropdown checkbox and radio group items to not close the menu when selected by default.

## 0.34.0

### Minor Changes

- d0a7c4c: adds the slider component and styles; bumps storybook dependencies

### Patch Changes

- ffb1f85: Create `getColor` utility to extract direct hex values from color JS objects for situations where you can't use a CSS variable. Also update the color and spacing objects to be typed as constants.

## 0.33.1

### Patch Changes

- fe19e42: Provide a CJS version of the foundations plugin for Jest users

## 0.33.0

### Minor Changes

- 8d566e4: Delete generated directory, create colors, primitiveColors, and semanticColors for convenience. Create initial kui-11 theme for KUI11 consumers who want to move over to the new components without any visual differences

## 0.32.0

### Minor Changes

- e862e9c: Add withLinks functionality to the existing tabs component

### Patch Changes

- d9d3437: Fix plugin util import for foundations to include file extension for CJS users
- 5e632da: Fix Popover content overflowing the window
- 019b255: Fix tailwind "px" size
- 96e7ba4: adjusts iframe sizing in docs and updates behavior of dialog components with no header text
- f365326: Remove unnecessary menu styles from dropdown

## 0.31.0

### Minor Changes

- 5e99cd2: Add internal tabs kind that removes styles

### Patch Changes

- 760ebf1: Update layout components to include fixed spacing values, and update documentation
- 5e99cd2: Remove Anchor visited styles

## 0.30.0

### Minor Changes

- a3329e3: adds the sidepanel component and relevant documentation

### Patch Changes

- 4245776: Add bottom border to Appbar component

## 0.29.0

### Minor Changes

- e3491e3: Previously our design tokens were using base-2 for size and Tailwind uses base-4 - we now have consolidated onto a base-4 system, so p-1 = --nv-size-100 = 4px

### Patch Changes

- 403f788: resolve cross-browser sizing issues in the logo component

## 0.28.0

### Minor Changes

- f9e3845: Update text tokens and usage to reflect new text styles
- a3dc94b: Add Anchor component to Foundations
- c88d25a: disables modality by default on dropdown and popover

### Patch Changes

- b0e65fd: Refactor vertical-nav styles to allow for easier overriding
- 8fcba8a: Generate `css-sizes.js` which is a report of the original and gzipped size of each CSS file we generate in foundations/dist

## 0.27.1

### Patch Changes

- aa27041: Refactor Switch CSS to set medium as default, fix broken small size, and simplify classes needed to use it
- 0e9b32e: Update `Button` so that it applies `:active` styles when `data-state="open"` is applied. This will result in an "opened" status being rendered for buttons used as Dropdown triggers and Popover triggers.

## 0.27.0

### Minor Changes

- f4b45fe: Update Tabs component to use mask-image to fade out overflow tabs instead of a gradient. This allows for tabs to be used on any background color, and means we no longer need the "surface" prop.

## 0.26.0

### Minor Changes

- db5b7da: Update Logo kind prop names to line up with what the logos actually are, and to line up with Figma
- db5b7da: Update AppBar styles to match new designs. Remove default responsive behaviour and add responsive logo, as well as easy access to the expander and logo components for convenience for consumers
- db5b7da: Fix TextArea and TextInput so they fill their entire container width. Add visual regression tests for these cases. Update TextArea styles to use the correct text styling for its content.

### Patch Changes

- 60488a7: Respect `actionsPosition` in `Banner` - if provided, it will override the default responsive behaviour of repositioning the action button
- db5b7da: Inject --nv-app-bar-height as a CSS variable so consumers can easily get the app bar height without needing to hardcode it

## 0.25.1

### Patch Changes

- 052998c: Compile types for the foundations plugin

## 0.25.0

### Minor Changes

- 805fdbd: refactor(foundations): move the plugin code out of src and just use JS to avoid needing a build step at all.

  - Simplify the integration methods to only the plugin since that is the only option supported by both Tailwind v3 + v4. Move utility files out of the scripts folder since I'll be re-using them.
  - Delete the old KUI11 Tailwind config - this is no longer necessary since we have KUI11 utilities available in the base plugin.
  - Update the Tailwind documentation to reflect the new changes.

- 85aa04a: add the text component

### Patch Changes

- ad35c65: Update dark tokens for badge
- 8038ece: add linting to changesets

## 0.24.0

### Minor Changes

- 2146f81: fix(button): preserve button height in flex container

## 0.23.0

### Minor Changes

- 8417ec4: feat(foundations): pull in new spacing tokens which can be compacted or spaced out
- 889fca7: fix(text-input): rendering a div within the text input root resulted in it rendering as "read-only". Updated the selectors to look at the actual value element.
  fix(text-area): rendering a div within the text area root resulted in it rendering as "read-only". Updated the selectors to look at the actual value element.
- 889fca7: refactor(text-input): rename TextInputValue to TextInputElement
  refactor(text-area): rename TextAreaValue to TextAreaElement
- 8417ec4: feat(card): update spacing to standard, spacious, and compact
  feat(modal): update spacing to standard, spacious, and compact
  feat(tag): update spacing to standard, spacious, and compact
- 012c59b: fix(badge): fix truncation issues
- bbda146: refactor(banner): update design

## 0.22.0

### Minor Changes

- acfe894: updates table spacing from spacious to roomy
- 8255d1a: feat(foundations): add KUI11 token utility classes, and only extend tailwind config - do not override it. This allows for the most flexibility when using tailwind and will make migrating apps that are already on tailwind over to foundations easier.

  These utility token classes are capable of being used within a KUI11 ThemeProvider by pointing to the CSS variable, but also support being used outside of a KUI11 ThemeProvider by providing fallback values. This will help libraries migrate off KUI11 which may not have control over the `ThemeProvider` component.

- 1d5ba35: chore(foundations):

  - sort tokens alphabetically for consistent file output
  - improve app.mjs by running tasks concurrently, and improve logging. Build in mode and property filtering

  feat(foundations):

  - update component CSS to use theme object to access tokens for safety
  - pull in latest tokens from foundations bringing in new design

### Patch Changes

- 19f50ad: adjusts attributes API usage for portal-ed and form base components
- 8255d1a: refactor(foundations): simplify build script, refactor utilities into a separate file. Allow tasks to run in parallel.
- 02e1acd: adds horizontal radio group support

## 0.21.0

### Minor Changes

- 587f92c: adds the popover component and applies minor tweaks to tooltip and table

## 0.20.0

### Minor Changes

- 2e04bae: adds the attribute API to various composed components allowing forwarding of native attributes
- bef6ffb: Add Notification component
- 8ceeca0: adds the table component and updates icon-related prop names

### Patch Changes

- 6c4ea72: update card border to not shift content

## 0.19.0

### Minor Changes

- 15a4be6: feat(kui): add combobox

### Patch Changes

- 63b3189: Update script to add density for brand
- a3e2190: fix(foundations): filter out spacing-level from spacing styles

## 0.18.2

### Patch Changes

- 624ef1c: Update text area and text input stories
- a8aaf9c: adjusts menu truncation behavior and adds dropdown side-alignment
- 868af44: enables polymorphic component support in all composable components

## 0.18.1

### Patch Changes

- 87cd0f6: Change from boolean floating to kind for floating page header

## 0.18.0

### Minor Changes

- 19d9a94: adds dropdown component and updates usage of Radix components

## 0.17.0

### Minor Changes

- 58fa6b9: Add floating variant to page header

### Patch Changes

- a8bafee: feat(foundations): update base styles to use minified theme css

## 0.16.0

### Minor Changes

- 614a03a: updates button styles and add button-group component
- 8474d36: Add page header component and fix docs

## 0.15.1

### Patch Changes

- ea06073: Update badge css

## 0.15.0

### Minor Changes

- 75ab691: updates component structures and prop naming to be more consistent

## 0.14.0

### Minor Changes

- bc0e50d: add panel component
- fa61a2a: adds the radio group component

## 0.13.1

### Patch Changes

- 5722b9d: removes dedicated label component and adjusts style application on switch and checkbox simple components

## 0.13.0

### Minor Changes

- e6f8458: Adds the TextArea component to Foundations and React

## 0.12.0

### Minor Changes

- 2430d25: feat(foundations): change class prefix from kui- to nv-
- 4e85e61: feat(foundations): add KUI11 tailwind theme option to withFoundations

### Patch Changes

- ee335cf: Update classes to use full word sizes
- 8b9b2fe: feat(foundations): add heading/text utilities to line up with Figma definitions

## 0.11.0

### Minor Changes

- e5c47b8: Add Toast to Foundations and React packages
- b8aec67: feat(kui): create tag component

### Patch Changes

- ea4d0aa: adds @kui/react modal styles + component and relevant docs

## 0.10.0

### Minor Changes

- 1494690: Add react and foundations menu implementation

### Patch Changes

- b9d2407: chore(foundations): update to use the new spacing tokens

## 0.9.1

### Patch Changes

- 9009feb: feat(foundations): add option to disable tailwind theme overrides, and document it

## 0.9.0

### Minor Changes

- 6ddb560: fix(foundations): update Jetbrains Mono font import away from using Google Fonts to using our self-hosted version. This allows us to remove the @import line which was previously failing because tailwind preflight code was injected above it resulting in the import being broken.
- c9fbf5e: fix(foundations): overhaul build process, fix incorrect token resolutions, extend theme instead of override

## 0.8.0

### Minor Changes

- 2e35d55: fix(foundations): remove global styles originating from base
- 44e86b9: adds the StatusMessage component and related documentation
- 8eb2321: Add the hero component to Foundations and React

## 0.7.1

### Patch Changes

- 26664a0: Update the token script to find all styles

## 0.7.0

### Minor Changes

- 29dc426: Adds the Switch component
- bf01bf8: Adds TextInput component

## 0.6.0

### Minor Changes

- f76b5bc: Add card component

## 0.5.3

### Patch Changes

- c063fb0: Fix components.min.css not being minified
- 259c104: Fix skeleton animation CSS being CPU intensive causing page crash

## 0.5.2

### Patch Changes

- e6325de: Fix: nested accordions always render as "open", update the CSS selector to look for the direct parent for data-state attribute

## 0.5.1

### Minor Changes

- b93a502: Prepare foundations for release. Reorganize files so built CSS lives in dist/ and tailwind code is in tailwind/. Include generated JS in git so that prettier can run on repo pull. Create a `withFoundations` util to enable usage of foundations in other projects.
- 39d1034: responsive grid
- d835106: Adds the Skeleton component

### Patch Changes

- df057d6: Adds glow to the spinner component

## 0.4.1

### Patch Changes

- 16b58b8: Fix styling on button, specifically asChild, to fit content

## 0.4.0

### Minor Changes

- 58031d3: Add App Bar component

### Patch Changes

- 296d579: Adds the ProgressBar Component

## 0.3.0

### Minor Changes

- 975cf30: Adds the Tooltip component to the kaizen-ui lib.
- d4d2f76: Responsive breakpoints

## 0.2.0

### Minor Changes

- 35cc888: Adds the new button styles for rounded buttons. Changes the button API to include a `color` prop.

### Patch Changes

- 4964102: Update tokens and new styles for banner

## 0.1.0

### Minor Changes

- 7db8218: update tokens
