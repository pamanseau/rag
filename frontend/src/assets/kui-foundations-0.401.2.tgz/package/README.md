# Kaizen UI - Foundations

For consumer use, please check out the [documentation site](https://virtual-front-end-initiative.gitlab-master-pages.nvidia.com/kaizen-ui/get-started/installation?tab=tailwind-css).

This package contains the foundational styles and utilities for Kaizen UI. It contains:

- scripts to generate a theme.generated.css from the KUI Design System in Figma containing CSS variables for the Kaizen UI Design systen
- CSS classes for styling components to follow the KUI Design System
- A tailwind plugin for easy access to the KUI Design System tokens

## Development

`pnpm build` will create the `dist` directory with the compiled CSS and JS files.

`pnpm dev` will run the build process with a watch flag, so you can see your changes in real-time.

`pnpm tokens` will regenerate the `src/tokens.js` file from the Figma file. This is only necessary if the design tokens have changed.

`pnpm run scripts:generate-assets` will generate the static assets for the Kaizen UI Foundations library. Use this to update documentation.

## Project Overview

We organize our CSS using the same layers system TailwindCSS leverages. [See here](https://tailwindcss.com/docs/adding-custom-styles#using-css-and-layer) under `Why does Tailwind group styles into "layers"?` for motivation details, an overview of the layers is:

> - The `base` layer is for things like reset rules or default styles applied to plain HTML elements.
> - The `components` layer is for class-based styles that you want to be able to override with utilities.
> - The `utilities` layer is for small, single-purpose classes that should always take precedence over any other styles.

As such within the `src` directory we have the following structure:

- `base.css` - contains the base styles for the project, this CSS will be applied to all elements
- `components/*.css` - contains the CSS for the components in the project
- `utilities/*.js` - contains the utilities
